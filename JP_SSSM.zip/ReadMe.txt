Some useful considerations on java component
1- JRE System Library 1.8.0.40
2- To execute from command line --> "C:\java -jar jpsssm.jar 120.0" 

Some details on this java implementation:
0- First Step is validating input price value. 
1- I've loaded Global Beverage Corporation Exchange on JTable (RegistryGBCEmodel --> Beveragecorpex.java)
2- I've recorded about more or less 1 Milion of trade stock on a Jtable in ten seconds (recTrademodel --> RecordTradeBeverage.java).
3- I've used randomic value,in order to record stock data.
4- I've used "Reflection" to load Stock Symbol Type Data (CommonStock.java,PreferredStock.java)

