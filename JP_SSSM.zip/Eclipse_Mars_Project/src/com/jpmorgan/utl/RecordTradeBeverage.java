package com.jpmorgan.utl;

import java.sql.Timestamp;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class RecordTradeBeverage {
	public static JTable recTradeBevCorpExc;
	public static DefaultTableModel tableModel;
	
	RecordTradeBeverage()
	{
		String columnNames[] = {"recTimestamp","StockSymbol","Quantity","BuyOrSellIndicator", "PriceinPennies"};	
		Object[][] data = {};
		
		tableModel = new DefaultTableModel(data, columnNames);
		recTradeBevCorpExc = new JTable(tableModel);	
		
	}
	public JTable AddRow(Timestamp date1, String stockSymbol, int quantity, String buyOrSellIndicator,double price,JTable recTradeTable){
						
			tableModel.addRow(new Object[]{date1,stockSymbol,quantity,buyOrSellIndicator,price});			
			return recTradeTable;
		}
	public JTable getStaticTable() {
		return recTradeBevCorpExc;
	}

}
