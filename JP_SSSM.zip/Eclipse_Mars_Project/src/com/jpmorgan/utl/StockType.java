package com.jpmorgan.utl;

public enum StockType {
	
	COMMON,PREFERRED
}