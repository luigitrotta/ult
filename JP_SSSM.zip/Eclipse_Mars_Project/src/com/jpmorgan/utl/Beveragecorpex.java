package com.jpmorgan.utl;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Beveragecorpex {
	public static JTable GloBevCorpExc;
	public static DefaultTableModel tableModel;
	
	Beveragecorpex()
	{
		String columnNames[] = {"StockSymbol","Type","LastDividend", "FixedDividend", "ParValue"};	
		Object[][] data = {
							{"TEA", "Common", 0,"", 100},
							{"POP", "Common", 8,"", 100},
							{"ALE", "Common", 23,"", 60},
							{"GIN", "Preferred",8,"2%", 100},
							{"JOE", "Common",13,"", 250}
						  };
		
		tableModel = new DefaultTableModel(data, columnNames);
		GloBevCorpExc = new JTable(tableModel);	
		
	}
	public JTable AddRow(String str1, String str2, String str3, String str4,String str5,JTable dynTable){
						
			tableModel.addRow(new Object[]{str1,str2,str3,str4,str5});			
			return dynTable;
		}
	public JTable getStaticTable() {
		return GloBevCorpExc;
	}
	public void setStaticTable(JTable staticTable) {
		GloBevCorpExc = staticTable;
	}
	
	
}
	
