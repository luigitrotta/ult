package com.jpmorgan.utl;

public class PreferredStock  extends Stock {

	private double fixedDividend = 0.0;	
	private double parValue = 0.0;
	private double price = 0.0;
	
	public PreferredStock(){
	        super("Preferred");
	}
	
	public PreferredStock(Double lastDividend,Double fixedDividend,Double parValue,Double price ){
		setFixedDividend(fixedDividend);
		setParValue(parValue);
		this.price=price;
	}
	
	public double getDividendYield() {		
		double dividendYield = 0.0;		
		dividendYield = (fixedDividend * parValue ) /price;
		//System.out.println("PreferredStock getDividendYield value " +dividendYield);
		/*
		if(Price > 0.0){								
				dividendYield = (fixedDividend * parValue ) / Price;
			}
		}
		else
		{
			System.out.println("Raise Issue Price is zero or negative");
		}
		*/
		return dividendYield;
	}
	
	/**
	 * 
	 * @return
	 */
	public double getFixedDividend() {
		return fixedDividend;
	}

	/**
	 * 
	 * @param fixedDividend
	 */
	public void setFixedDividend(double fixedDividend) {
		this.fixedDividend = fixedDividend;
	}
	
	/**
	 * 
	 * @return
	 */
	public double getParValue() {
		return parValue;
	}

	/**
	 * 
	 * @param parValue
	 */
	public void setParValue(double parValue) {
		this.parValue = parValue;
	}
	

}
