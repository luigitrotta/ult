package com.jpmorgan.utl;


public class Stock {
		
		
		
		/**
		 * 
		 */
		private String stockSymbol = null;
		
		/**
		 * 
		 */
		//private StockType stockType = StockType.COMMON;
		private String stockType ="";
		/**
		 * 
		 */
		//private double lastDividend = 0.0;
		
		/**
		 * 
		 */
		private double fixedDividend = 0.0;
		
		/**
		 * 
		 */
		private double parValue = 0.0;
			
		/**
		 * 
		 */
		private double Price = 0.0; 
		
		private double dividendYield=0.0;
		
		/**
		 * 
		 */
		
		public Stock(){								
		}
		
		public Stock(String stockType){
			this.stockType=stockType;						
		}
		
		public Stock(String stockType,double Dividend){
			this.stockType=stockType;						
		}

		/**
		 * 
		 * @return
		 */
		public String getStockSymbol() {
			return stockSymbol;
		}

		/**
		 * 
		 * @param stockSymbol
		 */
		public void setStockSymbol(String stockSymbol) {
			this.stockSymbol = stockSymbol;
		}

		/**
		 * 
		 * @return
		 */
		public String getStockType() {
			return stockType;
		}
		/*
		public StockType getStockType() {
			return stockType;
		}
		*/

		/*	
		
		public void setStockType(StockType stockType) {
			this.stockType = stockType;
		}
		*/
		public void setStockType(String stockType) {
			this.stockType = stockType;
		}

		/**
		 * 
		 * @return
		 */
		
		/*
		public double getLastDividend() {
			return lastDividend;
		}
		*/
		

		/**
		 * 
		 * @param lastDividend
		 */
		/*
		public void setLastDividend(double lastDividend) {
			this.lastDividend = lastDividend;
		}
		*/

		/**
		 * 
		 * @return
		 */
		public double getFixedDividend() {
			return fixedDividend;
		}

		/**
		 * 
		 * @param fixedDividend
		 */
		public void setFixedDividend(double fixedDividend) {
			this.fixedDividend = fixedDividend;
		}

		/**
		 * 
		 * @return
		 */
		public double getParValue() {
			return parValue;
		}

		/**
		 * 
		 * @param parValue
		 */
		public void setParValue(double parValue) {
			this.parValue = parValue;
		}
		
	
		
		/**
		 * 
		 * @return
		 */
		public double getDividendYield() {			
			return dividendYield;
		}


		/**
		 * 
		 * @return
		 */
		public double getPeRatio() {
			double peRatio = -1.0;
			
			if((Price > 0.0) &&  (getDividendYield() > 0.0)){
				peRatio = getPrice() / getDividendYield();	
			}
			
			return peRatio;
		}

		/**
		 * 
		 * @return
		 */
		public double getPrice() {
			return Price;
		}

		/**
		 * 
		 * @param tickerPrice
		 */
		public void setPrice(double Price) {			
			this.Price = Price;			
		}

		public void setDividendYield(double dividendYield) {
			this.dividendYield = dividendYield;
			
		}		
		
	}
