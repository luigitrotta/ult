package com.jpmorgan.utl;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JTable;
import javax.swing.table.TableModel;

import com.jpmorgan.utl.Beveragecorpex;

public class StartCalculation {
	
	public static JTable tableRegistryGBCE;
	public static JTable tableRecTrade;
	
	
	public static TableModel calculateDividendYield(double inputPrice) throws ReflectiveOperationException {
		Class noparams[] = {};
		
		int numRows =-1;					
		System.out.println("-------------------------------------------------------------------------------------");
		Beveragecorpex registryGBCE = new Beveragecorpex();		
		tableRegistryGBCE=registryGBCE.getStaticTable();
        javax.swing.table.TableModel RegistryGBCEmodel = tableRegistryGBCE.getModel();		
        numRows = RegistryGBCEmodel.getRowCount();        
        
        Stock stock = new Stock("");
        
        stock.setPrice(inputPrice);
        
        System.out.println("Input Price Value " + stock.getPrice());
        
        System.out.println("Start Calculating Dividend Yield for: ");
        for (int i=0; i < numRows; i++) {
            
	        System.out.print("    Dividend Yield " + (String) RegistryGBCEmodel.getValueAt(i, 0) + 
	            									"(" + (String) RegistryGBCEmodel.getValueAt(i, 1) + ")");
	            
	        double DividendYield = 0.0;
	        								
			Class clsStock = Class.forName("com.jpmorgan.utl." + (String) RegistryGBCEmodel.getValueAt(i, 1) + "Stock");				
			Constructor constructor = clsStock.getConstructor(Double.class,Double.class,Double.class,Double.class);
			//System.out.println(Arrays.toString(constructor.getParameterTypes()));				
			//System.out.println("Value [" + RegistryGBCEmodel.getValueAt(i, 3) + "]") ;
			double dividend=(Integer) RegistryGBCEmodel.getValueAt(i, 2);
			double fixed=  (Integer)  Integer.parseInt(((String) RegistryGBCEmodel.getValueAt(i, 3)).replace("%", "")+0);
			double parValue=(Integer) RegistryGBCEmodel.getValueAt(i, 4);
			Object obj = constructor.newInstance(dividend,fixed,parValue,inputPrice);								
			Method method = clsStock.getDeclaredMethod("getDividendYield",noparams);
			Object value = method.invoke(obj,null);
			DividendYield= (Double) value;							
		
	        stock.setDividendYield(DividendYield);
	        
	        if (stock.getPeRatio() > 0.0) {
	        	System.out.print("  " + DividendYield + " >>>>>> P/E Ratio " + stock.getPeRatio());
	        } else{
	        	System.out.print("  " + DividendYield + " >>>>>> P/E Ratio is undefined, dividend cannot be zero!");
	        }
	        System.out.println();
        }                
        System.out.println("-------------------------------------------------------------------------------------");
        return RegistryGBCEmodel;                   	        
	}
	
	public static TableModel recordTradedData() throws Exception {
		String[] arrRegistryGBCE = {"TEA","POP","POP","GIN","JOE"};
        String[] arrRegistryBuyOrSelling = {"B","S"};  
        int maxPrice=120000;
        int minPrice= 100; 
        int maxQuantity=900;
        int minQuantity=100;   
              
		Timestamp startTimestampRecTrade = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
		
		Timestamp currentTimestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(startTimestampRecTrade.getTime());
		cal.add(Calendar.SECOND,10);
		Timestamp stopTimestampRecTrade = new java.sql.Timestamp(cal.getTime().getTime());
		RecordTradeBeverage recTrade = new RecordTradeBeverage();		
		
			while (stopTimestampRecTrade.after(currentTimestamp))
			{								
				int idxarrRegistryGBCE = new Random().nextInt(arrRegistryGBCE.length);
				String rndRegistryGBCE = (arrRegistryGBCE[idxarrRegistryGBCE]);
				int idxRegistryBuyOrSelling = new Random().nextInt(arrRegistryBuyOrSelling.length);			
				String rndRegistryBuyOrSelling = (arrRegistryBuyOrSelling[idxRegistryBuyOrSelling]);
				double randomPrice = minPrice + (Math.random() * (maxPrice - minPrice));		                
		        int randomQuantity = (int) (minQuantity + (Math.random() * (maxQuantity - minQuantity)));							
				tableRecTrade=recTrade.AddRow(currentTimestamp,rndRegistryGBCE,randomQuantity,rndRegistryBuyOrSelling,randomPrice,recTrade.getStaticTable());			
				currentTimestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
				
			}		
		
		TableModel recTrademodel = tableRecTrade.getModel();
		System.out.println("recordTradedData row count [" + recTrademodel.getRowCount() +"]");
		System.out.println("-------------------------------------------------------------------------------------");
		return recTrademodel;
	}
	
	public static double calculateVWSP(TableModel RegistryGBCEmodel,TableModel recTrademodel,Map coeffStockSymbMap) throws Exception {
		
	    int quantity=0;
	    double coeff=0.00;
	    double VolWeStockPrice=0.00;
	    double GBCEAllShareIndex=1.00;
	    
	    for (int j = 0; j < RegistryGBCEmodel.getRowCount(); j++)
	    {	
	    	String stockSymbol = (String) RegistryGBCEmodel.getValueAt(j, 0);
        	for (int k = 0; k < recTrademodel.getRowCount(); k++){
	            if (stockSymbol.equalsIgnoreCase((String) recTrademodel.getValueAt(k, 1).toString())) 
	            {
	            	quantity = (Integer) recTrademodel.getValueAt(k, 2);
	            	coeff= (Double) coeffStockSymbMap.get(stockSymbol);
	            	VolWeStockPrice= coeff*quantity;	            	
	            }	            
	        }        	        	
        	System.out.println("Volume Weighted Stock Price for stockSymbol [" +stockSymbol + "]-[" + VolWeStockPrice + "]");
        	GBCEAllShareIndex=GBCEAllShareIndex * VolWeStockPrice;
	    } 	            
	    System.out.println("-------------------------------------------------------------------------------------");
	    return GBCEAllShareIndex;
	}
	
	public static Map storeInMapVWSPValue (TableModel RegistryGBCEmodel,TableModel recTrademodel) throws Exception {
		int sigmaQuantity = 0; 
        HashMap coeffStockSymbMap = new HashMap();
        double sigmaTradedPrice =0.00;       
	    for (int j = 0; j < RegistryGBCEmodel.getRowCount(); j++)
	    {	
	    	String stockSymbol = (String) RegistryGBCEmodel.getValueAt(j, 0);
        	for (int k = 0; k < recTrademodel.getRowCount(); k++){
	            if (stockSymbol.equalsIgnoreCase((String) recTrademodel.getValueAt(k, 1).toString())) 
	            {
	            	int amount = (Integer) recTrademodel.getValueAt(k, 2);
	            	sigmaTradedPrice+= (Double) recTrademodel.getValueAt(k, 4);
	            	sigmaQuantity += amount;
	            }
	        }        	        	        	
        	
        	if (sigmaQuantity > 0.0)
        	{
        		coeffStockSymbMap.put(stockSymbol, sigmaTradedPrice/sigmaQuantity);        		
        	}
        	else {
        		System.out.println("Sigma Quantity for " + stockSymbol + " cannot be zero!");        		
        	}
         	        
	    } 
	    
	    return coeffStockSymbMap;
	}
	
	public static void calculateVWSPGeometricMean(double GBCEAllShareIndexValue,TableModel RegistryGBCEmodel) throws Exception {
		double gm= Math.pow(GBCEAllShareIndexValue, 1/(double) RegistryGBCEmodel.getRowCount());
		System.out.println("GBCEAllShareIndex Value " + gm);
	}
	
	public static boolean  validateInputPrice (String inputPricefromCmdLine) {
		String validateInputString = inputPricefromCmdLine.trim();		  
		String regexDecimal = "^-?\\d*\\.\\d+$";
		String regexInteger = "^-?\\d+$";
		String regexDouble = regexDecimal + "|" + regexInteger;
		Pattern pattern = Pattern.compile(regexDouble);
		Matcher matcher = pattern.matcher(validateInputString);	
		return matcher.find();
	}
	
	public static void main(String[] args) {
						
		double inputPrice=0.0;
		System.out.println("Start of Program " + new java.sql.Timestamp(Calendar.getInstance().getTime().getTime()));
		
		
		if (args.length != 0) {			
			if (validateInputPrice(args[0])){
				inputPrice = Double.parseDouble(args[0]);
				if (inputPrice <= 0) {
					System.out.println("Price cannot be zero or negative!");
					System.out.println("End of Program " + new java.sql.Timestamp(Calendar.getInstance().getTime().getTime()));
					System.exit(1);
				}
			}
			else{
				System.out.println("Price is not a valid value!");
				System.exit(1);
			}
				
				
		}		
		
		TableModel registryGBCEmodel=null;
		TableModel recTrademodel=null;
		Map coeffStockSymbMap=null;
		double GBCEAllShareIndexValue=0.0;
		try{
			registryGBCEmodel = calculateDividendYield(inputPrice);
		} catch (ReflectiveOperationException e) {
			System.err.print("Error raise on calculateDividendYield [" + e.getMessage()+"]");
			System.exit(1);
		}		
		
		try{
			recTrademodel=recordTradedData();
		} catch (Exception e) {
			System.err.print("Error raise on recordTradedData [" + e.getMessage()+"]");
			System.exit(1);
		}		
		
		try{
			coeffStockSymbMap=storeInMapVWSPValue(registryGBCEmodel,recTrademodel);
		} catch (Exception e) {
			System.err.print("Error raise on storeInMapVWSPValue [" + e.getMessage()+"]");
			System.exit(1);
		}			
		try{
			GBCEAllShareIndexValue=calculateVWSP(registryGBCEmodel,recTrademodel,coeffStockSymbMap);
		} catch (Exception e) {
			System.err.print("Error raise on calculateVWSP [" + e.getMessage()+"]");
			System.exit(1);
		}				
		try{
			calculateVWSPGeometricMean(GBCEAllShareIndexValue,registryGBCEmodel);			 	 
		} catch (Exception e) {
			System.err.print("Error raise on calculateVWSPGeometricMean [" + e.getMessage()+"]");
			System.exit(1);
		}		
		System.out.println("-------------------------------------------------------------------------------------");
	    System.out.println("End of Program " + new java.sql.Timestamp(Calendar.getInstance().getTime().getTime()));
	    System.exit(0);
	}	
		
}
