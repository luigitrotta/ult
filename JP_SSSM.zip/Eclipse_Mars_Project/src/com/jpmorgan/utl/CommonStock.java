package com.jpmorgan.utl;

public class CommonStock extends Stock {
	
	private double lastDividend = 0.0;
	private double price = 0.0;
	public CommonStock(){
		super("Common");
	}
	
	public CommonStock(Double lastDividend,Double fixedDividend,Double parValue,Double price ){
		setLastDividend(lastDividend);
		this.price=price;
	}
	
	/**
	 * 
	 * @return
	 */
	public double getLastDividend() {
		return lastDividend;
	}

	/**
	 * 
	 * @param lastDividend
	 */
	public void setLastDividend(Double lastDividend) {
		this.lastDividend = lastDividend;
	}
	
	public double getDividendYield() {		
		double dividendYield = 0.0;
		
		dividendYield = getLastDividend()/price;
		//System.out.println("CommonStock getDividendYield value " + dividendYield);
		/*
		if(Price > 0.0){								
				dividendYield = (fixedDividend * parValue ) / Price;
			}
		}
		else
		{
			System.out.println("Raise Issue Price is zero or negative");
		}
		*/
		return dividendYield;
	}
	

}
